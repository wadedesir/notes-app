const teardown = () => process.exit(0)

export default teardown
